﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;
using Class_library;

namespace WPF
{
    [Serializable]
    public class ViewData: INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }
        public VMBenchmark Benchmark;
        [XmlIgnore] public VMBenchmark benchmark { get { return Benchmark; } set { Benchmark = value; OnPropertyChanged(nameof(Benchmark)); } }
        public bool changed=false;
        public bool AddVMTime(VMGrid grid, VMf F)
        {
            OnPropertyChanged(nameof(AddVMTime));
            Benchmark.AddVMTime(grid);
            changed = true;
            //OnPropertyChanged(nameof(benchmark.min_ratio_ep_ha));
            //OnPropertyChanged(nameof(benchmark.min_ratio_la_ha));
            //OnPropertyChanged(nameof(benchmark.minimal_coefficients));
            return changed;
        }
        public ViewData()
        {
            Benchmark = new VMBenchmark();
            //Benchmark.AllPropertiesChanged();
        }
        public bool AddVMAccuracy(VMGrid grid, VMf F)
        {
            OnPropertyChanged(nameof(AddVMAccuracy));
            Benchmark.AddVMAccuracy(grid);
            changed = true;
            return changed;
        }
        public bool Save(string filename)
        {
            FileStream file = null;
            try
            {
                using (file = new FileStream(filename, FileMode.OpenOrCreate))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(ViewData));
                    xmlSerializer.Serialize(file, this);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception: {ex.Message}");
                return false;
            }
            finally
            {
                if (file != null) file.Close();
            }
        }
        public ViewData Load(string filename)
        {
            FileStream file = null;
            ViewData loaded = new();
            try
            {
                using (file = new FileStream(filename, FileMode.Open))
                {
                    this.Benchmark.Accuracy_results.Clear();
                    this.Benchmark.Time_results.Clear();
                    this.Benchmark.min_ratio_ep_ha=0;
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(ViewData));
                    loaded = xmlSerializer.Deserialize(file) as ViewData;
                }
                return loaded;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception: {ex.Message}");
                return loaded;
            }
            finally
            {
                if (file != null) file.Close();
            }
        }

    }
}
