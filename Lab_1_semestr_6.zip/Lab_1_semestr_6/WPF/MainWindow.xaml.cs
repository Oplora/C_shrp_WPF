﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Class_library;
using Microsoft.Win32;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ViewData VD = new ViewData();
        public MainWindow()
        {
            
            InitializeComponent();
            DataContext = VD;
        }


        private void Make_New_VMBenchmark_object_Click(object sender, RoutedEventArgs e/*, System.ComponentModel.CancelEventArgs l*/)
        {
            if (VD.changed)
            {
                MessageBoxResult res = MessageBox.Show("Make new collection?", "Collection wasn't saved", MessageBoxButton.YesNo);
                if (res == MessageBoxResult.No)
                {
                    return;
                }
            }
            
            ViewData element = new();
            //int counts;
            //double beginning, ending;
            VD.benchmark.Time_results.Clear();
            VD.benchmark.Accuracy_results.Clear();
            VD.benchmark.Min_ratio_ep_ha = 0;
            VD.benchmark.Min_ratio_la_ha = 0;
            VD.benchmark.LastAccuracy = "";
            VD.benchmark.LastTime = "";
            VD.benchmark.MinimalCoefficients = $"VML_EP / VML_HA = {VD.benchmark.Min_ratio_ep_ha}\nVML_LA / VML_HA = {VD.benchmark.Min_ratio_la_ha}\n"; ;
            Collection_change.Text = "New collection";
            
            //MessageBox.Show(VD.benchmark.ToString());
            //Min_coefficients.Text = String.Empty;
            //Last_VMAccuracy.Text = "";
            //Last_VMTime.Text = "";

            //MessageBox.Show(this.Joints_Amount.Text);
            //MessageBox.Show(this.Interval_Beginning.Text);
            //MessageBox.Show(this.Interval_Ending.Text);
        }

        private void Open_File_Click(object sender, RoutedEventArgs e)
        {
            if (VD.changed)
            {
                MessageBoxResult res = MessageBox.Show("Load new collection?", "Collection wasn't saved", MessageBoxButton.YesNo);
                if (res == MessageBoxResult.No)
                {
                    return;
                }
            }

            OpenFileDialog f = new OpenFileDialog();
            if (f.ShowDialog() == true)
            {
                VD = VD.Load(f.FileName);
                DataContext = null;
                DataContext=VD;
            }
            VD.changed = false;
            Collection_change.Text = "New collection";
        }

        private void Save_File_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog f = new SaveFileDialog();
            if (f.ShowDialog()==true)
            {
                VD.Save(f.FileName);
                VD.changed = false;
            }
            //MessageBox.Show("You've pressed Save!");
        }
        private void Add_Time_Click(object sender, RoutedEventArgs e)
        {


            VMGrid Grid;
            try
            {
                if (Convert.ToInt32(Joints_Amount.Text) <= 1)
                {
                    throw new Exception("At least should be 2 counts");
                }

                if (Chosen_function.SelectedIndex == 0)
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.sin);

                }
                else if (Chosen_function.SelectedIndex == 1)
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.cos);
                }
                else
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.sincos);

                }
                VD.AddVMTime(Grid, Grid.function);
                MessageBox.Show(VD.benchmark.ToString());
                //Time_Window.Items.Add(VD.benchmark.time_results.Last());
                Collection_change.Text = "Collection changed"; // shouldn't be like this, need to rewrite
                //Min_coefficients.Text = VD.benchmark.MinimalCoefficientsToString();
                //Last_VMTime.Text = VD.benchmark.TimeToString("last");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception: {ex.Message}");
            }
            

            //MessageBox.Show(Convert.ToString(VD.benchmark.time_results.Count));

            //Time_Window.Items.Add(VD.benchmark.TimeT
            //Time_Window.Items.Clear();oString("hole"));
            //Collection_change.Text = "Collection_changed";
            //Min_coefficients.Text = VD.benchmark.MinimalCoefficientsToString();
            //Last_VMTime.Text = VD.benchmark.TimeToString("last");
        }

        private void Add_Accuracy_Click(object sender, RoutedEventArgs e)
        {
            VMGrid Grid;
            try
            {
                if (Convert.ToInt32(Joints_Amount.Text) <= 1)
                {
                    throw new Exception("At least should be 2 counts");
                }
                if (Chosen_function.SelectedIndex == 0)
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.sin);

                }
                else if (Chosen_function.SelectedIndex == 1)
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.cos);
                }
                else
                {
                    Grid = new VMGrid(Convert.ToInt32(Joints_Amount.Text), Convert.ToDouble(Interval_Beginning.Text), Convert.ToDouble(Interval_Ending.Text), VMf.sincos);

                }// time_data.AddVMTime(grid);
                VD.AddVMAccuracy(Grid, Grid.function);
                //MessageBox.Show(VD.benchmark.ToString());
                //Accuracy_Window.Items.Add(VD.benchmark.accuracy_results);
                Collection_change.Text = "Collection changed";
                //Last_VMAccuracy.Text = VD.benchmark.AccuracyToString("last");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception: {ex.Message}");
            }
            //Accuracy_Window.Items.Clear();
            //Accuracy_Window.Items.Add(VD.benchmark.AccuracyToString("hole"));
            //Collection_change.Text = "Collection changed";
            //Last_VMAccuracy.Text = VD.benchmark.AccuracyToString("last");




        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string is_saved = "Collection wasn't saved";
            if (VD.changed)
            {
                is_saved = "";
            }
            MessageBoxResult res = MessageBox.Show("Close the window?", is_saved, MessageBoxButton.YesNo);
            if (res == MessageBoxResult.No) e.Cancel = true;
        }
    }
}
