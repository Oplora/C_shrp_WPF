#include <iostream>
#include "TestDll.h"
#include "pch.h"

int main()
{
    int n = 5;
    double dbl_in = 5;
    double dbl_out = 0;
    test(n, dbl_in, &dbl_out);
    std::cout << dbl_out << std::endl;
}
