﻿// dllmain.cpp : Определяет точку входа для приложения DLL.
#include "pch.h"
#include "TestDll.h"
void test(int n, double dbl_in, double* dbl_out)
{
	*dbl_out = n + dbl_in;
}


