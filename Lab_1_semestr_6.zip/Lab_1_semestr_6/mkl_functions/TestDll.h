﻿#pragma once

extern "C" _declspec(dllexport)
void test(int n, double dbl_in, double* dbl_out);

