﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_library
{
    [Serializable]
    public struct VMTime
    {
        public VMGrid grid;
        public TimeSpan time_h;
        public TimeSpan time_l;
        public TimeSpan time_e;
        public double ratio_l_h;
        public double ratio_e_h;
        public override string ToString()
        {
            return grid.ToString() + "; " + "VML_HA: " + time_h.ToString() + "; " + "VML_LA: " + time_l.ToString() + "; " + "WML_EP: " + time_e.ToString() + "; " + "ratio_ep_ha: " + ratio_e_h.ToString() + "; " + "ratio_la_ha: " + ratio_l_h.ToString() + "\n";
        }


        public VMTime(VMGrid Grid, function F)
        {
            grid = Grid;
            int counts = Grid.counts;
            double[] Value_HA = new double[counts];
            double[] Value_LA = new double[counts];
            double[] Value_EP = new double[counts];
            double[] Args = new double[counts];
            for (int i = 0; i < counts; ++i)
            {
                Args[i] = grid.beginning + i * grid.step;
            }

            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();
            F(counts, Args, Value_HA, 'H');
            stopWatch.Stop();
            time_h = stopWatch.Elapsed;

            stopWatch.Reset();
            stopWatch.Start();
            F(counts, Args, Value_LA, 'L');
            stopWatch.Stop();
            time_l = stopWatch.Elapsed;

            stopWatch.Reset();
            stopWatch.Start();
            F(counts, Args, Value_EP, 'E');
            stopWatch.Stop();
            time_e = stopWatch.Elapsed;
            
            
            ratio_l_h = time_l / time_h;
            //ratio_l_h = time_l.TotalMilliseconds;

            ratio_e_h = time_e / time_h;
            //ratio_e_h = time_e.TotalMilliseconds;
        }
        public string FunctionAndGrid
        {
            get
            {
                return $"Function: {grid.function}, [{grid.beginning}, {grid.ending}], {grid.counts} nodes";
            }
        }
        public string DifferentModes
        {
            get
            {
                return $"VML_HA: {time_h}\nVML_EP: {time_e}\nVML_LA: {time_l}\n";
            }
        }


    }
}
