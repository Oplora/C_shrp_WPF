﻿using System;

namespace Class_library
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            VMGrid grid = new();
            VMBenchmark data = new VMBenchmark();
            data.AddVMTime(grid);
            data.AddVMAccuracy(grid);
            
            //data.AddVMTime(grid);
            //data.AddVMAccuracy(grid);
            Console.WriteLine(data.ToString());
            Console.WriteLine(data.Min_ratio_ep_ha);
            Console.ReadLine();
            
        }
    }
}
