﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_library
{
    [Serializable]
    public struct VMAccuracy
    {
        public VMGrid grid;
        public double max_abs_value_h_e;
        public double argument;
        public double HA_val_in_arg;
        public double LA_val_in_arg;
        public double EP_val_in_arg;
        //public double time_h;
        //public double time_l;
        //public double time_e;

    
        public VMAccuracy(VMGrid Grid, function F)
        {
            grid = Grid;
            int counts = Grid.counts;
            double[] Value_HA = new double[counts];
            double[] Value_LA = new double[counts];
            double[] Value_EP = new double[counts];
            double[] Args = new double[counts];
            for (int i = 0; i < counts; ++i)
            {
                Args[i] = grid.beginning + i * grid.step;
            }


            int k = 0;
            max_abs_value_h_e = 0;
            F(counts, Args, Value_HA, 'H');
            F(counts, Args, Value_EP, 'E');
            F(counts, Args, Value_LA, 'L');
            for (int i = 0; i < counts; i++)
            {
                double max = Math.Abs(Value_HA[i] - Value_EP[i]);
                if (max >= max_abs_value_h_e)
                {
                    max_abs_value_h_e = max;
                    k = i;
                }
            }
            argument = Args[k];
            HA_val_in_arg = Value_HA[k];
            LA_val_in_arg = Value_LA[k];
            EP_val_in_arg = Value_EP[k];
        }
        public override string ToString()
        {
            return grid.ToString() + "; " + "max_abs_value_h_e: " + max_abs_value_h_e.ToString() + "; " + "argument: " + argument.ToString() + "\n";
        }
        public string FunctionAndGrid
        {
            get
            {
                return $"Function: {grid.function}, [{grid.beginning}, {grid.ending}], {grid.counts} nodes";
            }
        }
        public string DifferentModes
        {
            get
            {
                return $"VML_HA: {HA_val_in_arg}\nVML_EP: {EP_val_in_arg}\nVML_LA: {LA_val_in_arg}\n";
            }
        }
    }
}
