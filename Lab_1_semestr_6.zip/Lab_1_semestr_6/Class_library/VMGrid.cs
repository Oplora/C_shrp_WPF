﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Class_library
{
    [Serializable]
    public class VMGrid
    {

            public static void Beta_function(int n, double[] a, double[] y, char m = 'a')  // DELETE THIS LINE AFTER TESTING
        {
            if (m == 'H')
            {
                for (int i = 0; i < n; ++i)
                {
                    y[i] = Math.Sin(a[i]);
                }
            }
            else if (m == 'E')
            {
                for (int i = 0; i < n; ++i)
                {
                    y[i] = Math.Cos(a[i]);
                }
            }
            else
            {
                for (int i = 0; i < n; ++i)
                {
                    y[i] = Math.Cos(a[i]) * Math.Sin(a[i]);
                }
            }


        }

        public int counts;
        public double beginning;
        public double ending;
        public double step 
        { 
            get 
            {
                double Step = (ending - beginning) / (counts - 1);
                if (Step < 0)
                {
                    throw new Exception("Beginning should be less than or equal to ending");
                }
                //throw new Exception("Beginning should be less than or equal to ending");
                return Step;

            } 
        }
        public VMf function;

        public VMGrid()
        {
            counts = 100;
            beginning = 0;
            ending = 1;
            function = VMf.sin;
        }
        public VMGrid(int Counts, double Beginning, double Ending, VMf Function)
        {
            counts = Counts;
            beginning = Beginning;
            ending = Ending;
            function = Function;
        }
        public override string ToString()
        {
            return "counts: " + counts.ToString() + "; " + "beginning: " + beginning.ToString() + "; " + "ending: " + ending.ToString() + "; " + "step: " + step.ToString() + "; " + "function: " + function.ToString();
        }

    }
}
