﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Class_library
{
    public delegate void function(int n, double[] a, double[] y, char m);
    [Serializable]
    public class VMBenchmark : INotifyPropertyChanged
    {

        [DllImport("..\\..\\..\\Build\\x64\\Debug\\mkl_functions.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void mkl_sin(int n, double[] a, double[] y, char m);


        [DllImport("..\\..\\..\\Build\\x64\\Debug\\mkl_functions.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void mkl_cos(int n, double[] a, double[] y, char m);

        [DllImport("..\\..\\..\\Build\\x64\\Debug\\mkl_functions.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void mkl_sincos(int n, double[] a, double[] y, char m);



        public ObservableCollection<VMTime> time_results = new ObservableCollection<VMTime>();
        [XmlIgnore] public ObservableCollection<VMTime> Time_results { get { return time_results; } }
        public ObservableCollection<VMAccuracy> accuracy_results = new ObservableCollection<VMAccuracy>();
        [XmlIgnore] public ObservableCollection<VMAccuracy> Accuracy_results { get { return accuracy_results; } }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string property = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        //public void AllPropertiesChanged()
        //{
        //    OnPropertyChanged(nameof(min_ratio_ep_ha));
        //    OnPropertyChanged(nameof(min_ratio_la_ha));
        //    OnPropertyChanged(nameof(lastTime));
        //    OnPropertyChanged(nameof(lastAccuracy));
        //    OnPropertyChanged(nameof(minimal_coefficients));
        //}
        public void AddVMTime(VMGrid grid)
        {
            VMTime time = new();
                time = new(grid, VMGrid.Beta_function);  // DELETE THIS LINE AFTER TESTING
            
            /*
            
            THIS IS HOW IT SHOULD BE !!!!!

            switch (grid.function)
            {
                case VMf.sin:
                    time = new(grid, mkl_sin);
                    break;
                case VMf.cos:
                    time = new(grid, mkl_cos);
                    break;
                case VMf.sincos:
                    time = new(grid, mkl_sincos);
                    break;
            }
            */
            time_results.Add(time);
            OnPropertyChanged(nameof(Min_ratio_ep_ha));
            OnPropertyChanged(nameof(Min_ratio_la_ha));
            OnPropertyChanged(nameof(lastTime));
            OnPropertyChanged(nameof(MinimalCoefficients));
        }
        public void AddVMAccuracy(VMGrid grid)
        {
            VMAccuracy accuracy = new();
                accuracy = new(grid, VMGrid.Beta_function); // DELETE THIS LINE AFTER TESTING
            /*
            
            THIS IS HOW IT SHOULD BE !!!!!

            switch (grid.function)
            {
                case VMf.sin:
                    accuracy = new(grid, mkl_sin);
                    break;
                case VMf.cos:
                    accuracy = new(grid, mkl_cos);
                    break;
                case VMf.sincos:
                    accuracy = new(grid, mkl_sincos);
                    break;
            }
            */
            accuracy_results.Add(accuracy);
            OnPropertyChanged(nameof(Min_ratio_ep_ha));
            OnPropertyChanged(nameof(Min_ratio_la_ha));
            OnPropertyChanged(nameof(lastTime));
            OnPropertyChanged(nameof(MinimalCoefficients));

        }
        public VMBenchmark()
        {
            time_results = new();
            accuracy_results = new();
            //min_ratio_ep_ha = 0;
            //min_ratio_la_ha = 0;
            //minimal_coefficients = "";
        }
        public double min_ratio_la_ha;
        public double Min_ratio_la_ha
        {
            get
            {
                if (time_results.Count != 0)
                {
                    int i = 0;
                    double[] ratio = new double[time_results.Count];
                    foreach (var item in time_results)
                    {
                        ratio[i] = item.ratio_l_h;
                        i += 1;
                    }
                    min_ratio_la_ha = ratio.Min();
                }
                else
                {
                    min_ratio_la_ha = 0;
                }

                return min_ratio_la_ha;


            }
            set
            {
                min_ratio_la_ha = value;
                OnPropertyChanged(nameof(min_ratio_ep_ha));
            }
        }

        public double min_ratio_ep_ha;
        public double Min_ratio_ep_ha
        {
            get
            {
                if (time_results.Count != 0)
                {
                    int i = 0;
                    double[] ratio = new double[time_results.Count];
                    foreach (var item in time_results)
                    {
                        ratio[i] = item.ratio_e_h;
                        i += 1;
                    }
                    min_ratio_ep_ha = ratio.Min();
                }
                else
                {
                    min_ratio_ep_ha = 0;
                }

                return min_ratio_ep_ha;


            }
            set
            {
                min_ratio_ep_ha = value;
                OnPropertyChanged(nameof(min_ratio_ep_ha));
            }
            //set
            //{
            //    if (time_results.Count != 0)
            //    {
            //        int i = 0;
            //        double[] ratio = new double[time_results.Count];
            //        foreach (var item in time_results)
            //        {
            //            ratio[i] = item.ratio_e_h;
            //            i += 1;
            //        }
            //        min_ratio_ep_ha = ratio.Min();
            //    }
               
            //}
        }

        public string minimal_coefficients;
        public string MinimalCoefficients
        {
            get
            {
                return $"VML_EP / VML_HA = {Min_ratio_ep_ha}\nVML_LA / VML_HA = {Min_ratio_la_ha}\n";
            }
            set
            {
                minimal_coefficients = value;
                OnPropertyChanged(nameof(MinimalCoefficients));
            }
        }




        public string lastAccuracy;
        public string LastAccuracy
        {
            get 
            { 
                if (accuracy_results.Count() != 0)
                {
                    lastAccuracy = accuracy_results.Last().ToString();
                    return lastAccuracy;
                }
                return "";
            }
            set
            {
                lastAccuracy = value;
                OnPropertyChanged(nameof(lastAccuracy));
            }
           
        }
        public string lastTime;
        public string LastTime
        {
            get 
            { 
                if (time_results.Count() != 0)
                {
                    lastTime = time_results.Last().ToString();
                    return lastTime;
                }
                return "";
            }
            set
            {
                lastTime = value;
                OnPropertyChanged(nameof(lastTime));
            }

        }
       
        //public VMAccuracy lastAccuracy;
        //public VMAccuracy LastAccuracy
        //{
        //    get { return lastAccuracy; }
        //    set
        //    {
        //        lastAccuracy = value;
        //        OnPropertyChanged(nameof(LastAccuracy));
        //    }
        //}
        //public event PropertyChangedEventHandler PropertyChanged;
        //public void OnPropertyChanged([CallerMemberName] string prop = "")
        //{
        //    if (PropertyChanged != null)
        //        PropertyChanged(this, new PropertyChangedEventArgs(prop));
        //}
        public override string ToString()
        {
            string info = "";
            if (time_results != null)
            {
                foreach (var elem in time_results)
                {
                    info += elem.ToString();
                }
            }
            if (accuracy_results != null)
            {
                foreach (var elem in accuracy_results)
                {
                    info += elem.ToString();
                }
            }

            return info;
        }
        public string TimeToString(string hole)
        {
            string info = "";
            if (hole == "hole")
            {
                if (time_results != null)
                {
                    foreach (var elem in time_results)
                    {
                        info += elem.ToString();
                    }
                }
            }
            else
            {
                info = time_results.Last().ToString();
            }

            return info;
        }
        public string AccuracyToString(string hole)
        {
            string info = "";
            if (hole == "hole")
            {
                if (accuracy_results != null)
                {
                    foreach (var elem in accuracy_results)
                    {
                        info += elem.ToString();
                    }
                }
            }
            else
            {
                info = accuracy_results.Last().ToString();
            }

            return info;
        }
        public string MinimalCoefficientsToString()
        {
            return $"VML_EP / VML_HA = {min_ratio_ep_ha}\nVML_LA / VML_HA = {Min_ratio_la_ha.ToString()}";
        }
        //public String Information;
        //public string information
        //{
        //    get
        //    {
        //        return Information;
        //    }
        //    set
        //    {
        //        string info = "";
        //        if (time_results != null)
        //        {
        //            foreach (var elem in time_results)
        //            {
        //                info += elem.ToString();
        //            }
        //        }
        //        if (accuracy_results != null)
        //        {
        //            foreach (var elem in accuracy_results)
        //            {
        //                info += elem.ToString();
        //            }
        //        }
        //        else
        //        {
        //            info = "The collection is empty";
        //        }
        //        Information = info;
        //    }

        //}

    }
}
